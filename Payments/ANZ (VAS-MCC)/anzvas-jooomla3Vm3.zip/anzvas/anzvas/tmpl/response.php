<?php
/**
 *
 * Paypal payment plugin
 *
 * @author Jeremy Magne
 * @version $Id: paypal.php 7217 2013-09-18 13:42:54Z alatak $
 * @package VirtueMart
 * @subpackage payment
 * Copyright (C) 2004 - 2016 Virtuemart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
 *
 * http://virtuemart.net
 */
defined('_JEXEC') or die();

$success = $viewData["success"];
$payment_name = $viewData["payment_name"];
$order = $viewData["order"];
$anz_data = $viewData["anz_response_data"];
?>
<br />
<table>
    <tr>
        <td>Payment Name:</td>
        <td><?php echo $payment_name; ?></td>
    </tr>
    <tr>
        <td>Status:</td>
        <td><?php echo $anz_data['status']; ?></td>
    </tr>
    <tr>
        <td>Your receipt number is:</td>
        <td><?php echo $anz_data['order_number']; ?></td>
    </tr>
    <tr>
        <td>Transaction amount:</td>
        <td><?php echo $anz_data['transaction_amount']; ?></td>
    </tr>
    <?php if (isset($anz_data['transaction_currency'])) { ?>
        <tr>
            <td><strong>Transaction currency:</strong></td>
            <td><strong><?php echo $anz_data['transaction_currency'] ?></strong></td>
        </tr>
    <?php } ?>
    <?php if (isset($anz_data['exchange_rate'])) { ?>
        <tr>
            <td>Exchange rate:</td>
            <td><?php echo $anz_data['exchange_rate'] ?></td>
        </tr>
    <?php } ?>
    <?php if (isset($anz_data['total_amount_due'])) { ?>
        <tr>
            <td>Total amount due:</td>
            <td><?php echo $anz_data['total_amount_due'] ?></td>
        </tr>
    <?php } ?>
    <?php if (isset($anz_data['disclaimer'])) { ?>
        <tr>
            <td></td>
            <td style="width: 79%;"><?php echo $anz_data['disclaimer'] ?></td>
        </tr>
    <?php } ?>
</table>
<?php if ($success) { ?>
    <br />
    <a class="vm-button-correct" href="<?php echo JRoute::_('index.php?option=com_virtuemart&view=orders&layout=details&order_number=' . $viewData["order"]['details']['BT']->order_number . '&order_pass=' . $viewData["order"]['details']['BT']->order_pass, false) ?>"><?php echo vmText::_('COM_VIRTUEMART_ORDER_VIEW_ORDER'); ?></a>
<?php } ?>
