@package 	Paypal Express Checkout Sample files
@copyright	Copyright (C) Computer - http://www.sanwebe.com All rights reserved.
@license	http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
@URL		http://www.sanwebe.com/2012/07/paypal-expresscheckout-with-php