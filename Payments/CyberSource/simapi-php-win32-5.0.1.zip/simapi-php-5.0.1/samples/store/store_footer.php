<?php
/* store_footer.php *****************************************************/
/*                                                                      */
/* Copyright 2004. CyberSource Corporation.  All rights reserved.       */
/************************************************************************/
?>
  
  <table width="100%">
     <tr>
      <td align="center" valign="middle" height="78"> 
        <p> (C) 2004 CyberSource Corporation </p>
        </td>
    </tr>
  </table>
