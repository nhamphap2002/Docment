<?php
/* store_header.php *****************************************************/
/*                                                                      */
/* Copyright 2004. CyberSource Corporation.  All rights reserved.       */
/************************************************************************/
?>
  
  <table width="100%" bgcolor="#FFFFFF" bordercolordark="#FFFFFF">
    <tr bgcolor="#CCCCCC"> 
      <td align="center" valign="middle" height="78"> 
        <p> <font size="+4" face="Helvetica, Arial, sans-serif">Sample Store
          </font></p>
        </td>
    </tr>
  </table>
