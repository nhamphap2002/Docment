<?php
/**
 * AutoloadFile 
 * @date 28/11/2012
 */
/**
 * AutoloadFile
 * @date 28/11/2012
 */
require_once dirname(__FILE__) . '/MywspackWsdlClass.php';
require_once dirname(__FILE__) . '/Get/Result/MywspackTypeGetTransactionDataResult.php';
require_once dirname(__FILE__) . '/Get/Response/MywspackTypeGetTransactionDataResponse.php';
require_once dirname(__FILE__) . '/Get/Data/MywspackTypeGetTransactionData.php';
require_once dirname(__FILE__) . '/Get/Dates/MywspackTypeGetTransactionDataBetweenDates.php';
require_once dirname(__FILE__) . '/Get/Response/MywspackTypeGetTransactionDataBetweenDatesResponse.php';
require_once dirname(__FILE__) . '/Validate/Response/MywspackTypeValidateCreditCardResponse.php';
require_once dirname(__FILE__) . '/Validate/Card/MywspackTypeValidateCreditCard.php';
require_once dirname(__FILE__) . '/Get/Result/MywspackTypeGetTransactionDataBetweenDatesResult.php';
require_once dirname(__FILE__) . '/Get/Result/MywspackTypeGetClientDataBetweenDatesResult.php';
require_once dirname(__FILE__) . '/Get/Response/MywspackTypeGetClientDataBetweenDatesResponse.php';
require_once dirname(__FILE__) . '/Post/Result/MywspackTypePostClientDataResult.php';
require_once dirname(__FILE__) . '/Post/Response/MywspackTypePostClientDataResponse.php';
require_once dirname(__FILE__) . '/Client/XML/MywspackTypeClientXML.php';
require_once dirname(__FILE__) . '/Get/Data/MywspackTypeGetClientData.php';
require_once dirname(__FILE__) . '/Get/Response/MywspackTypeGetClientDataResponse.php';
require_once dirname(__FILE__) . '/Get/Dates/MywspackTypeGetClientDataBetweenDates.php';
require_once dirname(__FILE__) . '/Get/Result/MywspackTypeGetClientDataResult.php';
require_once dirname(__FILE__) . '/Post/Data/MywspackTypePostClientData.php';
require_once dirname(__FILE__) . '/Post/MywspackServicePost.php';
require_once dirname(__FILE__) . '/Get/MywspackServiceGet.php';
require_once dirname(__FILE__) . '/Validate/MywspackServiceValidate.php';
require_once dirname(__FILE__) . '/MywspackClassMap.php';
?>