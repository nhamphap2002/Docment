<?php
/**
 * Class file for MywspackTypeGetTransactionDataBetweenDatesResult
 * @date 28/11/2012
 */
/**
 * Class MywspackTypeGetTransactionDataBetweenDatesResult
 * @date 28/11/2012
 */
class MywspackTypeGetTransactionDataBetweenDatesResult extends MywspackWsdlClass
{
	/**
	 * The any
	 * @var DOMDocument
	 */
	public $any;
	/**
	 * Constructor
	 * @param DOMDocument $_any any
	 * @return MywspackTypeGetTransactionDataBetweenDatesResult
	 */
	public function __construct($_any = null)
	{
		parent::__construct(array('any'=>$_any));
	}
	/**
	 * Set any
	 * @param DOMDocument $_any any
	 * @return DOMDocument
	 */
	public function setAny($_any)
	{
		return ($this->any = $_any);
	}
	/**
	 * Get any
	 * @return DOMDocument
	 */
	public function getAny()
	{
		if(!($this->any instanceof DOMDocument))
		{
			$dom = new DOMDocument('1.0','UTF-8');
			$dom->formatOutput = true;
			$dom->loadXML($this->any);
			$this->setAny($dom);
		}
		return $this->any;
	}
	/**
	 * Method returning the class name
	 * @return string __CLASS__
	 */
	public function __toString()
	{
		return __CLASS__;
	}
}
?>