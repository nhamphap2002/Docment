<?php

/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    vnphpexpert <vnphpexpert@gmail.com>
 *  @copyright 2007-2015 vnphpexpert
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of vnphpexpert
 */
class SecureFrame extends PaymentModule {

    private $html = '';
    private $post_errors = array();
    protected $backward = false;
    public $test_gateway_url = 'https://payment.securepay.com.au/test/v2/invoice';
    public $live_gateway_url = 'https://payment.securepay.com.au/v2/invoice';

    public function __construct() {
        $this->name = 'secureframe';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.1';
        $this->author = 'SecurePay';
        $this->controllers = array('payment', 'validation', 'success');
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $config = Configuration::getMultiple(
                        array('SECURE_FRAME_MERCHANT_ID',
                            'SECURE_FRAME_TRANSACTION_PASSWORD',
                            'SECURE_FRAME_TEST_MODE',
                            'SECURE_FRAME_CURRENCY',
                            'SECURE_FRAME_DISPLAY_CARDHOLDER_NAME',
                            'SECURE_FRAME_DISPLAY_RECEIPT',
                            'SECURE_FRAME_TEMPLATE_TYPE',
                            'SECURE_FRAME_IFRAME_WIDTH',
                            'SECURE_FRAME_IFRAME_HEIGHT',
                            'SECURE_FRAME_TRANSACTION_TYPE',
                            'SECURE_FRAME_SURCHARGE',
                            'SECURE_FRAME_SURCHARGE_VISA',
                            'SECURE_FRAME_SURCHARGE_VISA_VALUE',
                            'SECURE_FRAME_SURCHARGE_MASTERCARD',
                            'SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE',
                            'SECURE_FRAME_SURCHARGE_AMEX',
                            'SECURE_FRAME_SURCHARGE_AMEX_VALUE',
                            'SECURE_FRAME_REFUND_STATUS')
        );
        $this->merchant_id = $config['SECURE_FRAME_MERCHANT_ID'];
        $this->transaction_password = $config['SECURE_FRAME_TRANSACTION_PASSWORD'];
        $this->test_mode = $config['SECURE_FRAME_TEST_MODE'];
        $this->currency = $config['SECURE_FRAME_CURRENCY'];
        $this->display_cardholder_name = $config['SECURE_FRAME_DISPLAY_CARDHOLDER_NAME'];
        $this->display_securepay_receipt = $config['SECURE_FRAME_DISPLAY_RECEIPT'];
        $this->template_type = $config['SECURE_FRAME_TEMPLATE_TYPE'];
        $this->iframe_width = $config['SECURE_FRAME_IFRAME_WIDTH'];
        $this->iframe_height = $config['SECURE_FRAME_IFRAME_HEIGHT'];
        $this->transaction_type = $config['SECURE_FRAME_TRANSACTION_TYPE'];
        $this->refund_status_id = $config['SECURE_FRAME_REFUND_STATUS'];
        $this->surcharge = $config['SECURE_FRAME_SURCHARGE'];
        $this->surcharge_visa = $config['SECURE_FRAME_SURCHARGE_VISA'];
        $this->surcharge_visa_value = $config['SECURE_FRAME_SURCHARGE_VISA_VALUE'];
        $this->surcharge_mastercard = $config['SECURE_FRAME_SURCHARGE_MASTERCARD'];
        $this->surcharge_mastercard_value = $config['SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE'];
        $this->surcharge_amex = $config['SECURE_FRAME_SURCHARGE_AMEX'];
        $this->surcharge_amex_value = $config['SECURE_FRAME_SURCHARGE_AMEX_VALUE'];
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('SecurePay SecureFrame');
        $this->description = $this->l('Accept online credit card payments via SecurePay - Australia Post.');
        $this->confirmUninstall = $this->l('Are you sure about removing these details?');

        if (!count(Currency::checkPaymentCurrencies($this->id))) {
            $this->warning = $this->l('No currency has been set for this module.');
        }

        if (version_compare(_PS_VERSION_, '1.5', '<')) {
            $backward_error = $this->l('In order to work properly in PrestaShop v1.4, the Simplify Commerce module ');
            $backward_error .= $this->l('requires the backward compatibility module at least v0.3.');
            $url_download = $this->l('You can download this module for free here ');
            $url_download .= 'http://addons.prestashop.com/en/modules-prestashop/6222-backwardcompatibility.html';
            $this->backward_error = $backward_error . '<br />' . $url_download;

            if (file_exists(_PS_MODULE_DIR_ . 'backwardcompatibility/backward_compatibility/backward.php')) {
                include(_PS_MODULE_DIR_ . 'backwardcompatibility/backward_compatibility/backward.php');
                $this->backward = true;
            } else {
                $this->warning = $this->backward_error;
            }
        } else {
            $this->backward = true;
        }
    }

    public function install() {
        return (parent::install() && $this->registerHook('payment') && $this->registerHook('paymentReturn') && $this->registerHook('adminOrder'));
    }

    public function uninstall() {
        if (!Configuration::deleteByName('SECURE_FRAME_MERCHANT_ID') || !Configuration::deleteByName('SECURE_FRAME_TRANSACTION_PASSWORD') || !Configuration::deleteByName('SECURE_FRAME_TEST_MODE') || !Configuration::deleteByName('SECURE_FRAME_CURRENCY') || !Configuration::deleteByName('SECURE_FRAME_DISPLAY_CARDHOLDER_NAME') || !Configuration::deleteByName('SECURE_FRAME_DISPLAY_RECEIPT') || !Configuration::deleteByName('SECURE_FRAME_TEMPLATE_TYPE') || !Configuration::deleteByName('SECURE_FRAME_IFRAME_WIDTH') || !Configuration::deleteByName('SECURE_FRAME_IFRAME_HEIGHT') || !Configuration::deleteByName('SECURE_FRAME_TRANSACTION_TYPE') || !Configuration::deleteByName('SECURE_FRAME_REFUND_STATUS') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_VISA') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_VISA_VALUE') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_MASTERCARD') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_AMEX') || !Configuration::deleteByName('SECURE_FRAME_SURCHARGE_AMEX_VALUE') || !parent::uninstall()) {
            return false;
        }
        return true;
    }

    private function postValidation() {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('SECURE_FRAME_MERCHANT_ID')) {
                $this->post_errors[] = $this->l('Merchant ID required.');
            } elseif (!Tools::getValue('SECURE_FRAME_TRANSACTION_PASSWORD')) {
                $this->post_errors[] = $this->l('Transaction Password is required.');
            }
        }
    }

    private function postProcess() {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('SECURE_FRAME_MERCHANT_ID', Tools::getValue('SECURE_FRAME_MERCHANT_ID'));
            $tran_pass = Tools::getValue('SECURE_FRAME_TRANSACTION_PASSWORD');
            Configuration::updateValue('SECURE_FRAME_TRANSACTION_PASSWORD', $tran_pass);
            Configuration::updateValue('SECURE_FRAME_TEST_MODE', Tools::getValue('SECURE_FRAME_TEST_MODE'));
            Configuration::updateValue('SECURE_FRAME_CURRENCY', Tools::getValue('SECURE_FRAME_CURRENCY'));
            $card_name = Tools::getValue('SECURE_FRAME_DISPLAY_CARDHOLDER_NAME');
            Configuration::updateValue('SECURE_FRAME_DISPLAY_CARDHOLDER_NAME', $card_name);
            Configuration::updateValue('SECURE_FRAME_DISPLAY_RECEIPT', Tools::getValue('SECURE_FRAME_DISPLAY_RECEIPT'));
            Configuration::updateValue('SECURE_FRAME_TEMPLATE_TYPE', Tools::getValue('SECURE_FRAME_TEMPLATE_TYPE'));
            Configuration::updateValue('SECURE_FRAME_IFRAME_WIDTH', Tools::getValue('SECURE_FRAME_IFRAME_WIDTH'));
            Configuration::updateValue('SECURE_FRAME_IFRAME_HEIGHT', Tools::getValue('SECURE_FRAME_IFRAME_HEIGHT'));
            $tran_type = Tools::getValue('SECURE_FRAME_TRANSACTION_TYPE');
            Configuration::updateValue('SECURE_FRAME_TRANSACTION_TYPE', $tran_type);
            Configuration::updateValue('SECURE_FRAME_REFUND_STATUS', Tools::getValue('SECURE_FRAME_REFUND_STATUS'));
            Configuration::updateValue('SECURE_FRAME_SURCHARGE', Tools::getValue('SECURE_FRAME_SURCHARGE'));
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_VISA', Tools::getValue('SECURE_FRAME_SURCHARGE_VISA'));
            $visa_value = Tools::getValue('SECURE_FRAME_SURCHARGE_VISA_VALUE');
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_VISA_VALUE', $visa_value);
            $m_card = Tools::getValue('SECURE_FRAME_SURCHARGE_MASTERCARD');
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_MASTERCARD', $m_card);
            $m_value = Tools::getValue('SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE');
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE', $m_value);
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_AMEX', Tools::getValue('SECURE_FRAME_SURCHARGE_AMEX'));
            $amex_value = Tools::getValue('SECURE_FRAME_SURCHARGE_AMEX_VALUE');
            Configuration::updateValue('SECURE_FRAME_SURCHARGE_AMEX_VALUE', $amex_value);
        }
        $this->html .= $this->displayConfirmation($this->l('Settings updated'));
    }

    private function displaySecureFrame() {
        return $this->display(__FILE__, 'infos.tpl');
    }

    public function getContent() {
        if (Tools::isSubmit('btnSubmit')) {
            $this->postValidation();
            if (!count($this->post_errors)) {
                $this->postProcess();
            } else {
                foreach ($this->_posterrors as $err) {
                    $this->html .= $this->displayError($err);
                }
            }
        } else {
            $this->html .= '<br />';
        }
        $this->html .= $this->displaySecureFrame();
        $this->html .= $this->renderForm();
        return $this->html;
    }

    public function hookPayment($params) {
        if (!$this->active) {
            return;
        }
        if (!$this->checkCurrency($params['cart'])) {
            return;
        }

        $this->smarty->assign(array(
            'this_path' => $this->_path,
            'this_path_bw' => $this->_path,
            'this_path_ssl' => Tools::getShopDomainSsl(true, true) . __PS_BASE_URI__ . 'modules/' . $this->name . '/'
        ));
        return $this->display(__FILE__, 'payment.tpl');
    }

    public function hookPaymentReturn($params) {
        if (!$this->active) {
            return;
        }

        $this->smarty->assign(array(
            'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
            'id_order' => $params['objOrder']->id,
            'txnid' => $this->context->cookie->txnid,
            'restext' => $this->context->cookie->restext,
            'amount' => $this->context->cookie->amount,
        ));
        return $this->display(__FILE__, 'payment_return.tpl');
    }

    public function hookAdminOrder($params) {
        if (Tools::getValue('secureframe')) {
            switch (Tools::getValue('secureframe')) {
                case 'refundOk':
                    $message = $this->l('Refund has been made.');
                    break;
                case 'refundError':
                    $message = $this->l('Refund request unsuccessful. Error when making refund request');
                    break;
            }
            if (isset($message) && $message) {
                $this->html .= '
				<br />
				<div class="module_confirmation conf confirm" style="width: 400px;">
					<img src="' . _PS_IMG_ . 'admin/ok.gif" alt="" title="" /> ' . $message . '
				</div>';
            }
        }
        if ($this->canRefund((int) $params['id_order'])) {
            $this->html .= '<div class="panel"><fieldset style="width:400px;">
<legend><img src="' . _MODULE_DIR_ . $this->name . '/logo.png" alt="" /> ' . $this->l('SecurePay Refund') . '</legend>
				<form method="post" action="' . htmlentities($_SERVER['REQUEST_URI']) . '">
				<input type="hidden" name="id_order" value="' . (int) $params['id_order'] . '" />';
            $order = new Order((int) $params['id_order']);
            $total_paid = $order->total_paid;
            $this->html .= '<p class="center">Total Refunded Amount: $' . $total_paid . '</p>
			<p class="center"><input type="submit" class="button" name="submitSecurepayRefund" 
			value="' . $this->l('Refund total transaction : $' . $total_paid) . '" '
                    . 'onclick="if (!confirm(\'' . $this->l('Are you sure?') . '\'))return false;" /></p>';
            $this->html .= '</form>';
            $this->postRefundProcess();
            $this->html .= '</fieldset></div>';
        }
        return $this->html;
    }

    private function postRefundProcess() {
        if (Tools::isSubmit('submitSecurepayRefund')) {
            require_once('libs/securepay_xml_api.php');
            $id_order = Tools::getValue('id_order');
            $order = new Order($id_order);
            $payments = $order->getOrderPaymentCollection();
            $transaction_id = '';
            if (count($payments)) {
                foreach ($payments as $payment) {
                    if ($payment->transaction_id != '') {
                        $transaction_id = $payment->transaction_id;
                    }
                }
            }
            $payment_mode = ($this->test_mode != '1' ? SECUREPAY_GATEWAY_MODE_LIVE : SECUREPAY_GATEWAY_MODE_TEST);
            $tran_pass = $this->transaction_password;
            $txn_object = new securepay_xml_transaction($payment_mode, $this->merchant_id, $tran_pass, '');
            $banktxn_id = $txn_object->processCreditRefund($order->total_paid, $order->id_cart, $transaction_id);
            if (!$banktxn_id) {
                $result = $this->l('Empty SecurePay response.');
                $status = 'refundError';
            } else {
                $result = sprintf($this->l('Refunded $%s - Refund ID: %s'), $order->total_paid, $banktxn_id);
                $status = 'refundOk';
                $history = new OrderHistory();
                $history->id_order = (int) $id_order;
                $history->id_employee = 0;
                $history->id_order_state = (int) $this->refund_status_id;
                $history->add();
            }
            //log results
            if (isset($result)) {
                $msg = new Message();
                $msg->message = $result;
                $msg->id_order = (int) $id_order;
                $msg->private = 1;
                $msg->add();
            }
            $param = '&vieworder&secureframe=' . $status . '&token=' . Tools::getValue('token');
            Tools::redirectAdmin(AdminController::$currentIndex . '&id_order=' . (int) $id_order . $param);
        }
    }

    private function canRefund($id_order) {
        if (!(int) $id_order) {
            return false;
        }
        $order = new Order($id_order);
        $payments = $order->getOrderPaymentCollection();
        $transaction_id = '';
        if (count($payments)) {
            foreach ($payments as $payment) {
                if ($payment->transaction_id != '') {
                    $transaction_id = $payment->transaction_id;
                }
            }
        }
        if ($order->current_state == $this->refund_status_id || $transaction_id == '') {
            return false;
        }
        return true;
    }

    /* hook function when order status change */

    public function hookActionOrderStatusUpdate($params) {
        $id_order = $params['id_order'];
        $order = new Order($id_order);
        $payments = $order->getOrderPaymentCollection();
        $transaction_id = '';
        if (count($payments)) {
            foreach ($payments as $payment) {
                if ($payment->transaction_id != '') {
                    $transaction_id = $payment->transaction_id;
                }
            }
        }
        if ($order->module == 'secureframe' && $params['newOrderStatus']->id == 7 && $transaction_id != '') {
            require_once('libs/securepay_xml_api.php');
            $pay_mode = ($this->test_mode != '1' ? SECUREPAY_GATEWAY_MODE_LIVE : SECUREPAY_GATEWAY_MODE_TEST);
            $txn_object = new securepay_xml_transaction($pay_mode, $this->merchant_id, $this->transaction_password, '');
            $banktxn_id = $txn_object->processCreditRefund($order->total_paid, $order->id_cart, $transaction_id);
            if (!$banktxn_id) {
                $result = $this->l('Empty SecurePay response.');
            } else {
                $result = sprintf($this->l('Refunded $%s - Refund ID: %s'), $order->total_paid, $banktxn_id);
            }

            //log results
            if (isset($result)) {
                $msg = new Message();
                $msg->message = $result;
                $msg->id_order = (int) $id_order;
                $msg->private = 1;
                $msg->add();
            }
        }
    }

    public function checkCurrency($cart) {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);

        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function renderForm() {
        $fields_form = array();
        $fields_form[0] = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('SecurePay Account Details'),
                    'icon' => 'icon-envelope'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Merchant ID'),
                        'name' => 'SECURE_FRAME_MERCHANT_ID',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Transaction Password'),
                        'name' => 'SECURE_FRAME_TRANSACTION_PASSWORD',
                    ),
                    array(
                        //'type' => 'radio',
                        'type' => 'switch',
                        'is_bool' => true,
                        'label' => $this->l('Test Mode'),
                        'name' => 'SECURE_FRAME_TEST_MODE',
                        'values' => array(
                            array(
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'value' => 0,
                                'label' => $this->l('No')
                            ),
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Currency'),
                        'name' => 'SECURE_FRAME_CURRENCY',
                    ),
                    array(
                        'type' => 'switch',
                        'is_bool' => true,
                        'label' => $this->l('Display Cardholder Name'),
                        'name' => 'SECURE_FRAME_DISPLAY_CARDHOLDER_NAME',
                        'values' => array(
                            array(
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'value' => 0,
                                'label' => $this->l('No')
                            ),
                        )
                    ),
                    array(
                        'type' => 'switch',
                        'is_bool' => true,
                        'label' => $this->l('Display SecurePay Receipt Page'),
                        'name' => 'SECURE_FRAME_DISPLAY_RECEIPT',
                        'values' => array(
                            array(
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'value' => 0,
                                'label' => $this->l('No')
                            ),
                        )
                    ),
                    array(
                        'type' => 'radio',
                        'label' => $this->l('Template Type'),
                        'name' => 'SECURE_FRAME_TEMPLATE_TYPE',
                        'values' => array(
                            array(
                                'value' => 'iframe',
                                'label' => $this->l('Iframe')
                            ),
                            array(
                                'value' => 'default',
                                'label' => $this->l('Default')
                            ),
                        )
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Iframe Width'),
                        'name' => 'SECURE_FRAME_IFRAME_WIDTH',
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Iframe Height'),
                        'name' => 'SECURE_FRAME_IFRAME_HEIGHT',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Transaction Type'),
                        'name' => 'SECURE_FRAME_TRANSACTION_TYPE',
                        'options' => array(
                            'query' => self::getTypeOptions(),
                            'id' => 'id', 'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Retund Order status'),
                        'name' => 'SECURE_FRAME_REFUND_STATUS',
                        'options' => array(
                            'query' => OrderState::getOrderStates($this->context->language->id),
                            'id' => 'id_order_state',
                            'name' => 'name'
                        )
                    )
                )
            ),
        );
        $fields_form[1] = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Surcharge'),
                    'icon' => 'icon-link'
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'is_bool' => true,
                        'label' => $this->l('Surcharge'),
                        'name' => 'SECURE_FRAME_SURCHARGE',
                        'values' => array(
                            array(
                                'value' => 1,
                                'label' => $this->l('Yes')
                            ),
                            array(
                                'value' => 0,
                                'label' => $this->l('No')
                            ),
                        )
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Visa'),
                        'name' => 'SECURE_FRAME_SURCHARGE_VISA',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => 'None'),
                                array('id' => 'flat', 'name' => 'Flat'),
                                array('id' => 'percentage', 'name' => 'Percentage')
                            ),
                            'id' => 'id', 'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Visa surcharge value'),
                        'name' => 'SECURE_FRAME_SURCHARGE_VISA_VALUE',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Mastercard'),
                        'name' => 'SECURE_FRAME_SURCHARGE_MASTERCARD',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => 'None'),
                                array('id' => 'flat', 'name' => 'Flat'),
                                array('id' => 'percentage', 'name' => 'Percentage')
                            ),
                            'id' => 'id', 'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Mastercard surcharge value'),
                        'name' => 'SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE',
                    ),
                    array(
                        'type' => 'select',
                        'label' => $this->l('Amex'),
                        'name' => 'SECURE_FRAME_SURCHARGE_AMEX',
                        'options' => array(
                            'query' => array(
                                array('id' => '', 'name' => 'None'),
                                array('id' => 'flat', 'name' => 'Flat'),
                                array('id' => 'percentage', 'name' => 'Percentage')
                            ),
                            'id' => 'id', 'name' => 'name'
                        ),
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Amex surcharge value'),
                        'name' => 'SECURE_FRAME_SURCHARGE_AMEX_VALUE',
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int) Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        $helper->allow_employee_form_lang = $form_lang ? $form_lang : 0;
        $this->fields_form = array();
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $params = '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false) . $params;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm($fields_form);
    }

    protected static function getTypeOptions() {
        $data = array(
            array('id' => '0', 'name' => 'PAYMENT'),
            array('id' => '1', 'name' => 'PREAUTH'),
            array('id' => '2', 'name' => 'PAYMENT with FRAUDGUARD'),
            array('id' => '3', 'name' => 'PREAUTH with FRAUDGUARD'),
            array('id' => '4', 'name' => 'PAYMENT with 3D Secure'),
            array('id' => '5', 'name' => 'PREAUTH with 3D Secure'),
            array('id' => '6', 'name' => 'PAYMENT with FRAUDGUARD and 3D Secure'),
            array('id' => '7', 'name' => 'PREAUTH with FRAUDGUARD and 3D Secure'),
        );
        return $data;
    }

    public function getConfigFieldsValues() {
        $m_id = Tools::getValue('SECURE_FRAME_MERCHANT_ID', Configuration::get('SECURE_FRAME_MERCHANT_ID'));
        $con_tran_pass = Configuration::get('SECURE_FRAME_TRANSACTION_PASSWORD');
        $pass = Tools::getValue('SECURE_FRAME_TRANSACTION_PASSWORD', $con_tran_pass);
        $mod = Tools::getValue('SECURE_FRAME_TEST_MODE', Configuration::get('SECURE_FRAME_TEST_MODE'));
        $curr = Tools::getValue('SECURE_FRAME_CURRENCY', Configuration::get('SECURE_FRAME_CURRENCY'));
        $con_card_name = Configuration::get('SECURE_FRAME_DISPLAY_CARDHOLDER_NAME');
        $name = Tools::getValue('SECURE_FRAME_DISPLAY_CARDHOLDER_NAME', $con_card_name);
        $pt = Tools::getValue('SECURE_FRAME_DISPLAY_RECEIPT', Configuration::get('SECURE_FRAME_DISPLAY_RECEIPT'));
        $type = Tools::getValue('SECURE_FRAME_TEMPLATE_TYPE', Configuration::get('SECURE_FRAME_TEMPLATE_TYPE'));
        $width = Tools::getValue('SECURE_FRAME_IFRAME_WIDTH', Configuration::get('SECURE_FRAME_IFRAME_WIDTH'));
        $height = Tools::getValue('SECURE_FRAME_IFRAME_HEIGHT', Configuration::get('SECURE_FRAME_IFRAME_HEIGHT'));
        $con_tran_type = Configuration::get('SECURE_FRAME_TRANSACTION_TYPE');
        $tran_type = Tools::getValue('SECURE_FRAME_TRANSACTION_TYPE', $con_tran_type);
        $status = Tools::getValue('SECURE_FRAME_REFUND_STATUS', Configuration::get('SECURE_FRAME_REFUND_STATUS'));
        $surcharge = Tools::getValue('SECURE_FRAME_SURCHARGE', Configuration::get('SECURE_FRAME_SURCHARGE'));
        $visa = Tools::getValue('SECURE_FRAME_SURCHARGE_VISA', Configuration::get('SECURE_FRAME_SURCHARGE_VISA'));
        $con_visa_value = Configuration::get('SECURE_FRAME_SURCHARGE_VISA_VALUE');
        $visa_value = Tools::getValue('SECURE_FRAME_SURCHARGE_VISA_VALUE', $con_visa_value);
        $con_sur_mas = Configuration::get('SECURE_FRAME_SURCHARGE_MASTERCARD');
        $m_card = Tools::getValue('SECURE_FRAME_SURCHARGE_MASTERCARD', $con_sur_mas);
        $con_m_value = Configuration::get('SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE');
        $m_card_value = Tools::getValue('SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE', $con_m_value);
        $amex = Tools::getValue('SECURE_FRAME_SURCHARGE_AMEX', Configuration::get('SECURE_FRAME_SURCHARGE_AMEX'));
        $con_amex_value = Configuration::get('SECURE_FRAME_SURCHARGE_AMEX_VALUE');
        $amex_value = Tools::getValue('SECURE_FRAME_SURCHARGE_AMEX_VALUE', $con_amex_value);
        return array(
            'SECURE_FRAME_MERCHANT_ID' => $m_id,
            'SECURE_FRAME_TRANSACTION_PASSWORD' => $pass,
            'SECURE_FRAME_TEST_MODE' => $mod,
            'SECURE_FRAME_CURRENCY' => $curr,
            'SECURE_FRAME_DISPLAY_CARDHOLDER_NAME' => $name,
            'SECURE_FRAME_DISPLAY_RECEIPT' => $pt,
            'SECURE_FRAME_TEMPLATE_TYPE' => $type,
            'SECURE_FRAME_IFRAME_WIDTH' => $width,
            'SECURE_FRAME_IFRAME_HEIGHT' => $height,
            'SECURE_FRAME_TRANSACTION_TYPE' => $tran_type,
            'SECURE_FRAME_REFUND_STATUS' => $status,
            'SECURE_FRAME_SURCHARGE' => $surcharge,
            'SECURE_FRAME_SURCHARGE_VISA' => $visa,
            'SECURE_FRAME_SURCHARGE_VISA_VALUE' => $visa_value,
            'SECURE_FRAME_SURCHARGE_MASTERCARD' => $m_card,
            'SECURE_FRAME_SURCHARGE_MASTERCARD_VALUE' => $m_card_value,
            'SECURE_FRAME_SURCHARGE_AMEX' => $amex,
            'SECURE_FRAME_SURCHARGE_AMEX_VALUE' => $amex_value,
        );
    }

}
