<?php
/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    vnphpexpert <vnphpexpert@gmail.com>
 *  @copyright 2007-2015 vnphpexpert
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of vnphpexpert
 */

/**
 * @since 1.5.0
 */
class SecureFramePaymentModuleFrontController extends ModuleFrontController
{

    public $ssl = true;
    public $display_column_left = false;

    /**
     * @see FrontController::initContent()
     */
    public function initContent()
    {
        parent::initContent();
        $cart = $this->context->cart;
        if (!$this->module->checkCurrency($cart)) {
            Tools::redirect('index.php?controller=order');
        }
        $amount = number_format($cart->getOrderTotal(true, Cart::BOTH), 2, '.', '') * 100;
        $return_url = Context::getContext()->link->getModuleLink('secureframe', 'success');
        $notify_url = Context::getContext()->link->getModuleLink('secureframe', 'validation');
        $cancel_url = Context::getContext()->link->getPageLink('order', true, null, 'step=3');
        $fp_timestamp = gmdate('YmdHis');
        $fingerprint = $this->module->merchant_id . '|' . $this->module->transaction_password . '|';
        $fingerprint .= $this->module->transaction_type . '|' . $cart->id . '|' . $amount . '|' . $fp_timestamp;
        $fingerprint = hash('sha1', $fingerprint);
        $parameters = array(
            'bill_name' => 'transact',
            'merchant_id' => $this->module->merchant_id,
            'primary_ref' => $cart->id,
            'txn_type' => $this->module->transaction_type,
            'currency' => $this->module->currency,
            'amount' => $amount,
            'fp_timestamp' => $fp_timestamp,
            'fingerprint' => $fingerprint,
            'return_url' => $return_url,
            'return_url_target' => 'parent',
            'cancel_url' => $cancel_url,
            'callback_url' => $notify_url,
            'template' => $this->module->template_type,
        );
        if ($this->module->display_securepay_receipt == 1) {
            $parameters['display_receipt'] = 'yes';
        } else {
            $parameters['display_receipt'] = 'no';
        }
        if ($this->module->display_cardholder_name == 1) {
            $parameters['display_cardholder_name'] = 'yes';
        } else {
            $parameters['display_cardholder_name'] = 'no';
        }
        if ($this->module->surcharge == 1) {
            $surcharge_visa_percen = 0;
            $surcharge_mastercard_percen = 0;
            $surcharge_amex_percen = 0;
            //visa
            if ($this->module->surcharge_visa == 'flat') {
                $visa_value = $this->module->surcharge_visa_value;
                $surcharge_visa_percen = round($visa_value / $cart->getOrderTotal(true, Cart::BOTH), 2);
            } elseif ($this->module->surcharge_visa == 'percentage') {
                $surcharge_visa_percen = round($this->module->surcharge_visa_value, 2);
            }
            //mastercard
            if ($this->module->surcharge_mastercard == 'flat') {
                $sur_val = $this->module->surcharge_mastercard_value;
                $surcharge_mastercard_percen = round($sur_val / $cart->getOrderTotal(true, Cart::BOTH), 2);
            } elseif ($this->module->surcharge_mastercard == 'percentage') {
                $surcharge_mastercard_percen = round($this->module->surcharge_mastercard_value, 2);
            }
            //amex
            if ($this->module->surcharge_amex == 'flat') {
                $amex_val = $this->module->surcharge_amex_value;
                $surcharge_amex_percen = round($amex_val / $cart->getOrderTotal(true, Cart::BOTH), 2);
            } elseif ($this->module->surcharge_amex == 'percentage') {
                $surcharge_amex_percen = round($this->module->surcharge_amex_value, 2);
            }
            if ($surcharge_visa_percen > 0) {
                $parameters['surcharge_rate_v'] = $surcharge_visa_percen;
            }
            if ($surcharge_mastercard_percen > 0) {
                $parameters['surcharge_rate_m'] = $surcharge_mastercard_percen;
            }
            if ($surcharge_amex_percen > 0) {
                $parameters['surcharge_rate_a'] = $surcharge_amex_percen;
            }
        }
        if ($this->module->test_mode == 1) {
            $securepayframe_gateway_url = $this->module->test_gateway_url;
        } else {
            $securepayframe_gateway_url = $this->module->live_gateway_url;
        }
        $base_url = __PS_BASE_URI__ . 'modules/' . $this->module->name . '/';
        $this->context->smarty->assign(array(
            'gateway_url' => $securepayframe_gateway_url,
            'template_type' => $this->module->template_type,
            'iframe_width' => !empty($this->module->iframe_width) ? $this->module->iframe_width . 'px' : '60%',
            'iframe_height' => !empty($this->module->iframe_height) ? $this->module->iframe_height . 'px' : '60%',
            'target' => ($this->module->template_type == 'iframe') ? 'target="chekout_frame" style="display:none"' : '',
            'parameters' => $parameters,
            'nbProducts' => $cart->nbProducts(),
            //'cust_currency' => $cart->id_currency,
            //'currencies' => $this->module->getCurrency((int)$cart->id_currency),
            'total' => $cart->getOrderTotal(true, Cart::BOTH),
            'this_path' => $this->module->getPathUri(),
            'this_path_bw' => $this->module->getPathUri(),
            'this_path_ssl' => Tools::getShopDomainSsl(true, true) . $base_url
        ));
        $this->setTemplate('payment_execution.tpl');
    }
}
