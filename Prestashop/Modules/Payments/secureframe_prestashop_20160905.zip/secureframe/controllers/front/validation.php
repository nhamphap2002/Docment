<?php
/**
 * 2007-2015 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    vnphpexpert <vnphpexpert@gmail.com>
 *  @copyright 2007-2015 vnphpexpert
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of vnphpexpert
 */

/**
 * @since 1.5.0
 */
class SecureFrameValidationModuleFrontController extends ModuleFrontController
{

    /**
     * @see FrontController::postProcess()
     */
    public function postProcess()
    {
        $id_cart = Tools::getValue('refid');
        $fingerprint = Tools::getValue('fingerprint');
        $timestamp = Tools::getValue('timestamp');
        $amount = Tools::getValue('amount');
        $summarycode = Tools::getValue('summarycode');
        $txnid = Tools::getValue('txnid');
        $rescode = Tools::getValue('rescode');
        $cart = new Cart($id_cart);
        $cat_condition = ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0);
        if ($cat_condition || !$this->module->active) {
            die('Cannot create order for this cart.');
        }
        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            die('No customer for this order.');
        }
        $currency = new Currency((int) $cart->id_currency);
        $fingerprint_string = $this->module->merchant_id . '|' . $this->module->transaction_password . '|';
        $fingerprint_string .= $id_cart . '|' . $amount . '|' . $timestamp . '|' . $summarycode;
        $fingerprint_hash = hash('sha1', $fingerprint_string);
        if ($fingerprint_hash == $fingerprint && in_array($rescode, array('00', '08', '11'))) {
            //success transaction
            $res_data = print_r($_POST, true);
            $payment = Configuration::get('PS_OS_PAYMENT');
            $name = $this->module->displayName;
            $tran_id = array('transaction_id' => $txnid);
            $key = $customer->secure_key;
            $c_id = (int) $currency->id;
            $am_per = $amount / 100;
            $this->module->validateOrder($cart->id, $payment, $am_per, $name, $res_data, $tran_id, $c_id, false, $key);
        }
    }
}
