<?php return array (
  'AbstractLogger' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'AbstractLoggerCore' => 
  array (
    'path' => 'classes/log/AbstractLogger.php',
    'type' => 'abstract class',
  ),
  'Address' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AddressController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AddressControllerCore' => 
  array (
    'path' => 'controllers/front/AddressController.php',
    'type' => 'class',
  ),
  'AddressCore' => 
  array (
    'path' => 'classes/Address.php',
    'type' => 'class',
  ),
  'AddressFormat' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AddressFormatCore' => 
  array (
    'path' => 'classes/AddressFormat.php',
    'type' => 'class',
  ),
  'AddressesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AddressesControllerCore' => 
  array (
    'path' => 'controllers/front/AddressesController.php',
    'type' => 'class',
  ),
  'AdminAccessController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAccessControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAccessController.php',
    'type' => 'class',
  ),
  'AdminAddonsCatalogController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAddonsCatalogControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAddonsCatalogController.php',
    'type' => 'class',
  ),
  'AdminAddressesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAddressesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAddressesController.php',
    'type' => 'class',
  ),
  'AdminAdminPreferencesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAdminPreferencesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAdminPreferencesController.php',
    'type' => 'class',
  ),
  'AdminAttachmentsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAttachmentsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAttachmentsController.php',
    'type' => 'class',
  ),
  'AdminAttributeGeneratorController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAttributeGeneratorControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAttributeGeneratorController.php',
    'type' => 'class',
  ),
  'AdminAttributesGroupsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminAttributesGroupsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminAttributesGroupsController.php',
    'type' => 'class',
  ),
  'AdminBackupController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminBackupControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminBackupController.php',
    'type' => 'class',
  ),
  'AdminCarrierWizardController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCarrierWizardControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCarrierWizardController.php',
    'type' => 'class',
  ),
  'AdminCarriersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCarriersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCarriersController.php',
    'type' => 'class',
  ),
  'AdminCartRulesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCartRulesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCartRulesController.php',
    'type' => 'class',
  ),
  'AdminCartsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCartsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCartsController.php',
    'type' => 'class',
  ),
  'AdminCategoriesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCategoriesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCategoriesController.php',
    'type' => 'class',
  ),
  'AdminCmsCategoriesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCmsCategoriesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCmsCategoriesController.php',
    'type' => 'class',
  ),
  'AdminCmsContentController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCmsContentControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCmsContentController.php',
    'type' => 'class',
  ),
  'AdminCmsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCmsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCmsController.php',
    'type' => 'class',
  ),
  'AdminContactsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminContactsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminContactsController.php',
    'type' => 'class',
  ),
  'AdminController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminControllerCore' => 
  array (
    'path' => 'classes/controller/AdminController.php',
    'type' => 'class',
  ),
  'AdminCountriesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCountriesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCountriesController.php',
    'type' => 'class',
  ),
  'AdminCurrenciesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCurrenciesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCurrenciesController.php',
    'type' => 'class',
  ),
  'AdminCustomerPreferencesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCustomerPreferencesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCustomerPreferencesController.php',
    'type' => 'class',
  ),
  'AdminCustomerThreadsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCustomerThreadsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCustomerThreadsController.php',
    'type' => 'class',
  ),
  'AdminCustomersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminCustomersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminCustomersController.php',
    'type' => 'class',
  ),
  'AdminDashboardController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminDashboardControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminDashboardController.php',
    'type' => 'class',
  ),
  'AdminDeliverySlipController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminDeliverySlipControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminDeliverySlipController.php',
    'type' => 'class',
  ),
  'AdminEmailsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminEmailsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminEmailsController.php',
    'type' => 'class',
  ),
  'AdminEmployeesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminEmployeesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminEmployeesController.php',
    'type' => 'class',
  ),
  'AdminFeaturesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminFeaturesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminFeaturesController.php',
    'type' => 'class',
  ),
  'AdminGendersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminGendersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminGendersController.php',
    'type' => 'class',
  ),
  'AdminGeolocationController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminGeolocationControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminGeolocationController.php',
    'type' => 'class',
  ),
  'AdminGroupsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminGroupsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminGroupsController.php',
    'type' => 'class',
  ),
  'AdminImagesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminImagesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminImagesController.php',
    'type' => 'class',
  ),
  'AdminImportController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminImportControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminImportController.php',
    'type' => 'class',
  ),
  'AdminInformationController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminInformationControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminInformationController.php',
    'type' => 'class',
  ),
  'AdminInvoicesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminInvoicesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminInvoicesController.php',
    'type' => 'class',
  ),
  'AdminLanguagesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminLanguagesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminLanguagesController.php',
    'type' => 'class',
  ),
  'AdminLocalizationController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminLocalizationControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminLocalizationController.php',
    'type' => 'class',
  ),
  'AdminLoginController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminLoginControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminLoginController.php',
    'type' => 'class',
  ),
  'AdminLogsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminLogsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminLogsController.php',
    'type' => 'class',
  ),
  'AdminMaintenanceController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminMaintenanceControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminMaintenanceController.php',
    'type' => 'class',
  ),
  'AdminManufacturersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminManufacturersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminManufacturersController.php',
    'type' => 'class',
  ),
  'AdminMarketingController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminMarketingControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminMarketingController.php',
    'type' => 'class',
  ),
  'AdminMetaController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminMetaControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminMetaController.php',
    'type' => 'class',
  ),
  'AdminModulesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminModulesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminModulesController.php',
    'type' => 'class',
  ),
  'AdminModulesPositionsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminModulesPositionsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminModulesPositionsController.php',
    'type' => 'class',
  ),
  'AdminNotFoundController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminNotFoundControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminNotFoundController.php',
    'type' => 'class',
  ),
  'AdminOrderMessageController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminOrderMessageControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminOrderMessageController.php',
    'type' => 'class',
  ),
  'AdminOrderPreferencesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminOrderPreferencesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminOrderPreferencesController.php',
    'type' => 'class',
  ),
  'AdminOrdersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminOrdersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminOrdersController.php',
    'type' => 'class',
  ),
  'AdminOutstandingController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminOutstandingControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminOutstandingController.php',
    'type' => 'class',
  ),
  'AdminPPreferencesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminPPreferencesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminPPreferencesController.php',
    'type' => 'class',
  ),
  'AdminPaymentController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminPaymentControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminPaymentController.php',
    'type' => 'class',
  ),
  'AdminPdfController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminPdfControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminPdfController.php',
    'type' => 'class',
  ),
  'AdminPerformanceController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminPerformanceControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminPerformanceController.php',
    'type' => 'class',
  ),
  'AdminPreferencesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminPreferencesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminPreferencesController.php',
    'type' => 'class',
  ),
  'AdminProductsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminProductsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminProductsController.php',
    'type' => 'class',
  ),
  'AdminProfilesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminProfilesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminProfilesController.php',
    'type' => 'class',
  ),
  'AdminQuickAccessesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminQuickAccessesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminQuickAccessesController.php',
    'type' => 'class',
  ),
  'AdminRangePriceController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminRangePriceControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminRangePriceController.php',
    'type' => 'class',
  ),
  'AdminRangeWeightController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminRangeWeightControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminRangeWeightController.php',
    'type' => 'class',
  ),
  'AdminReferrersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminReferrersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminReferrersController.php',
    'type' => 'class',
  ),
  'AdminRequestSqlController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminRequestSqlControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminRequestSqlController.php',
    'type' => 'class',
  ),
  'AdminReturnController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminReturnControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminReturnController.php',
    'type' => 'class',
  ),
  'AdminScenesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminScenesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminScenesController.php',
    'type' => 'class',
  ),
  'AdminSearchConfController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSearchConfControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSearchConfController.php',
    'type' => 'class',
  ),
  'AdminSearchController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSearchControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSearchController.php',
    'type' => 'class',
  ),
  'AdminSearchEnginesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSearchEnginesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSearchEnginesController.php',
    'type' => 'class',
  ),
  'AdminShippingController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminShippingControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminShippingController.php',
    'type' => 'class',
  ),
  'AdminShopController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminShopControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminShopController.php',
    'type' => 'class',
  ),
  'AdminShopGroupController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminShopGroupControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminShopGroupController.php',
    'type' => 'class',
  ),
  'AdminShopUrlController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminShopUrlControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminShopUrlController.php',
    'type' => 'class',
  ),
  'AdminSlipController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSlipControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSlipController.php',
    'type' => 'class',
  ),
  'AdminSpecificPriceRuleController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSpecificPriceRuleControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSpecificPriceRuleController.php',
    'type' => 'class',
  ),
  'AdminStatesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStatesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStatesController.php',
    'type' => 'class',
  ),
  'AdminStatsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStatsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStatsController.php',
    'type' => 'class',
  ),
  'AdminStatsTabController' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'AdminStatsTabControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStatsTabController.php',
    'type' => 'abstract class',
  ),
  'AdminStatusesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStatusesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStatusesController.php',
    'type' => 'class',
  ),
  'AdminStockConfigurationController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStockConfigurationControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStockConfigurationController.php',
    'type' => 'class',
  ),
  'AdminStockCoverController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStockCoverControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStockCoverController.php',
    'type' => 'class',
  ),
  'AdminStockInstantStateController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStockInstantStateControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStockInstantStateController.php',
    'type' => 'class',
  ),
  'AdminStockManagementController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStockManagementControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStockManagementController.php',
    'type' => 'class',
  ),
  'AdminStockMvtController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStockMvtControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStockMvtController.php',
    'type' => 'class',
  ),
  'AdminStoresController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminStoresControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminStoresController.php',
    'type' => 'class',
  ),
  'AdminSuppliersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSuppliersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSuppliersController.php',
    'type' => 'class',
  ),
  'AdminSupplyOrdersController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminSupplyOrdersControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminSupplyOrdersController.php',
    'type' => 'class',
  ),
  'AdminTab' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'AdminTabCore' => 
  array (
    'path' => 'classes/AdminTab.php',
    'type' => 'abstract class',
  ),
  'AdminTabsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTabsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTabsController.php',
    'type' => 'class',
  ),
  'AdminTagsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTagsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTagsController.php',
    'type' => 'class',
  ),
  'AdminTaxRulesGroupController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTaxRulesGroupControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTaxRulesGroupController.php',
    'type' => 'class',
  ),
  'AdminTaxesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTaxesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTaxesController.php',
    'type' => 'class',
  ),
  'AdminThemesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminThemesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminThemesController.php',
    'type' => 'class',
  ),
  'AdminTrackingController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTrackingControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTrackingController.php',
    'type' => 'class',
  ),
  'AdminTranslationsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminTranslationsControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminTranslationsController.php',
    'type' => 'class',
  ),
  'AdminWarehousesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminWarehousesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminWarehousesController.php',
    'type' => 'class',
  ),
  'AdminWebserviceController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminWebserviceControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminWebserviceController.php',
    'type' => 'class',
  ),
  'AdminZonesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AdminZonesControllerCore' => 
  array (
    'path' => 'controllers/admin/AdminZonesController.php',
    'type' => 'class',
  ),
  'Alias' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AliasCore' => 
  array (
    'path' => 'classes/Alias.php',
    'type' => 'class',
  ),
  'Attachment' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AttachmentController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AttachmentControllerCore' => 
  array (
    'path' => 'controllers/front/AttachmentController.php',
    'type' => 'class',
  ),
  'AttachmentCore' => 
  array (
    'path' => 'classes/Attachment.php',
    'type' => 'class',
  ),
  'Attribute' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AttributeCore' => 
  array (
    'path' => 'classes/Attribute.php',
    'type' => 'class',
  ),
  'AttributeGroup' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AttributeGroupCore' => 
  array (
    'path' => 'classes/AttributeGroup.php',
    'type' => 'class',
  ),
  'AuthController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'AuthControllerCore' => 
  array (
    'path' => 'controllers/front/AuthController.php',
    'type' => 'class',
  ),
  'BestSalesController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'BestSalesControllerCore' => 
  array (
    'path' => 'controllers/front/BestSalesController.php',
    'type' => 'class',
  ),
  'Blowfish' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'BlowfishCore' => 
  array (
    'path' => 'classes/Blowfish.php',
    'type' => 'class',
  ),
  'CMS' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CMSCategory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CMSCategoryCore' => 
  array (
    'path' => 'classes/CMSCategory.php',
    'type' => 'class',
  ),
  'CMSCore' => 
  array (
    'path' => 'classes/CMS.php',
    'type' => 'class',
  ),
  'CSV' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CSVCore' => 
  array (
    'path' => 'classes/CSV.php',
    'type' => 'class',
  ),
  'Cache' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'CacheApc' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CacheApcCore' => 
  array (
    'path' => 'classes/cache/CacheApc.php',
    'type' => 'class',
  ),
  'CacheCore' => 
  array (
    'path' => 'classes/cache/Cache.php',
    'type' => 'abstract class',
  ),
  'CacheFs' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CacheFsCore' => 
  array (
    'path' => 'classes/cache/CacheFs.php',
    'type' => 'class',
  ),
  'CacheMemcache' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CacheMemcacheCore' => 
  array (
    'path' => 'classes/cache/CacheMemcache.php',
    'type' => 'class',
  ),
  'CacheXcache' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CacheXcacheCore' => 
  array (
    'path' => 'classes/cache/CacheXcache.php',
    'type' => 'class',
  ),
  'Carrier' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CarrierCore' => 
  array (
    'path' => 'classes/Carrier.php',
    'type' => 'class',
  ),
  'CarrierModule' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'CarrierModuleCore' => 
  array (
    'path' => 'classes/module/CarrierModule.php',
    'type' => 'abstract class',
  ),
  'Cart' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CartController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CartControllerCore' => 
  array (
    'path' => 'controllers/front/CartController.php',
    'type' => 'class',
  ),
  'CartCore' => 
  array (
    'path' => 'classes/Cart.php',
    'type' => 'class',
  ),
  'CartRule' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CartRuleCore' => 
  array (
    'path' => 'classes/CartRule.php',
    'type' => 'class',
  ),
  'Category' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CategoryController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CategoryControllerCore' => 
  array (
    'path' => 'controllers/front/CategoryController.php',
    'type' => 'class',
  ),
  'CategoryCore' => 
  array (
    'path' => 'classes/Category.php',
    'type' => 'class',
  ),
  'ChangeCurrencyController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ChangeCurrencyControllerCore' => 
  array (
    'path' => 'controllers/front/ChangeCurrencyController.php',
    'type' => 'class',
  ),
  'Chart' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ChartCore' => 
  array (
    'path' => 'classes/Chart.php',
    'type' => 'class',
  ),
  'CmsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CmsControllerCore' => 
  array (
    'path' => 'controllers/front/CmsController.php',
    'type' => 'class',
  ),
  'Combination' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CombinationCore' => 
  array (
    'path' => 'classes/Combination.php',
    'type' => 'class',
  ),
  'CompareController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CompareControllerCore' => 
  array (
    'path' => 'controllers/front/CompareController.php',
    'type' => 'class',
  ),
  'CompareProduct' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CompareProductCore' => 
  array (
    'path' => 'classes/CompareProduct.php',
    'type' => 'class',
  ),
  'Configuration' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ConfigurationCore' => 
  array (
    'path' => 'classes/Configuration.php',
    'type' => 'class',
  ),
  'ConfigurationKPI' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ConfigurationKPICore' => 
  array (
    'path' => 'classes/ConfigurationKPI.php',
    'type' => 'class',
  ),
  'ConfigurationTest' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ConfigurationTestCore' => 
  array (
    'path' => 'classes/ConfigurationTest.php',
    'type' => 'class',
  ),
  'Connection' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ConnectionCore' => 
  array (
    'path' => 'classes/Connection.php',
    'type' => 'class',
  ),
  'ConnectionsSource' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ConnectionsSourceCore' => 
  array (
    'path' => 'classes/ConnectionsSource.php',
    'type' => 'class',
  ),
  'Contact' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ContactController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ContactControllerCore' => 
  array (
    'path' => 'controllers/front/ContactController.php',
    'type' => 'class',
  ),
  'ContactCore' => 
  array (
    'path' => 'classes/Contact.php',
    'type' => 'class',
  ),
  'Context' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ContextCore' => 
  array (
    'path' => 'classes/Context.php',
    'type' => 'class',
  ),
  'Controller' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ControllerCore' => 
  array (
    'path' => 'classes/controller/Controller.php',
    'type' => 'abstract class',
  ),
  'ControllerFactory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ControllerFactoryCore' => 
  array (
    'path' => 'classes/ControllerFactory.php',
    'type' => 'class',
  ),
  'Cookie' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CookieCore' => 
  array (
    'path' => 'classes/Cookie.php',
    'type' => 'class',
  ),
  'Country' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CountryCore' => 
  array (
    'path' => 'classes/Country.php',
    'type' => 'class',
  ),
  'County' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CountyCore' => 
  array (
    'path' => 'classes/County.php',
    'type' => 'class',
  ),
  'Currency' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CurrencyCore' => 
  array (
    'path' => 'classes/Currency.php',
    'type' => 'class',
  ),
  'Customer' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CustomerCore' => 
  array (
    'path' => 'classes/Customer.php',
    'type' => 'class',
  ),
  'CustomerMessage' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CustomerMessageCore' => 
  array (
    'path' => 'classes/CustomerMessage.php',
    'type' => 'class',
  ),
  'CustomerThread' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CustomerThreadCore' => 
  array (
    'path' => 'classes/CustomerThread.php',
    'type' => 'class',
  ),
  'Customization' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'CustomizationCore' => 
  array (
    'path' => 'classes/Customization.php',
    'type' => 'class',
  ),
  'DateRange' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DateRangeCore' => 
  array (
    'path' => 'classes/DateRange.php',
    'type' => 'class',
  ),
  'Db' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'DbCore' => 
  array (
    'path' => 'classes/db/Db.php',
    'type' => 'abstract class',
  ),
  'DbMySQLi' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DbMySQLiCore' => 
  array (
    'path' => 'classes/db/DbMySQLi.php',
    'type' => 'class',
  ),
  'DbPDO' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DbPDOCore' => 
  array (
    'path' => 'classes/db/DbPDO.php',
    'type' => 'class',
  ),
  'DbQuery' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DbQueryCore' => 
  array (
    'path' => 'classes/db/DbQuery.php',
    'type' => 'class',
  ),
  'Delivery' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DeliveryCore' => 
  array (
    'path' => 'classes/Delivery.php',
    'type' => 'class',
  ),
  'Discount' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DiscountController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DiscountControllerCore' => 
  array (
    'path' => 'controllers/front/DiscountController.php',
    'type' => 'class',
  ),
  'DiscountCore' => 
  array (
    'path' => 'classes/Discount.php',
    'type' => 'class',
  ),
  'Dispatcher' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'DispatcherCore' => 
  array (
    'path' => 'classes/Dispatcher.php',
    'type' => 'class',
  ),
  'Employee' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'EmployeeCore' => 
  array (
    'path' => 'classes/Employee.php',
    'type' => 'class',
  ),
  'Feature' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'FeatureCore' => 
  array (
    'path' => 'classes/Feature.php',
    'type' => 'class',
  ),
  'FeatureValue' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'FeatureValueCore' => 
  array (
    'path' => 'classes/FeatureValue.php',
    'type' => 'class',
  ),
  'FileLogger' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'FileLoggerCore' => 
  array (
    'path' => 'classes/log/FileLogger.php',
    'type' => 'class',
  ),
  'FileUploader' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'FileUploaderCore' => 
  array (
    'path' => 'classes/FileUploader.php',
    'type' => 'class',
  ),
  'FrontController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'FrontControllerCore' => 
  array (
    'path' => 'classes/controller/FrontController.php',
    'type' => 'class',
  ),
  'Gender' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GenderCore' => 
  array (
    'path' => 'classes/Gender.php',
    'type' => 'class',
  ),
  'GetFileController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GetFileControllerCore' => 
  array (
    'path' => 'controllers/front/GetFileController.php',
    'type' => 'class',
  ),
  'Group' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GroupCore' => 
  array (
    'path' => 'classes/Group.php',
    'type' => 'class',
  ),
  'GroupReduction' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GroupReductionCore' => 
  array (
    'path' => 'classes/GroupReduction.php',
    'type' => 'class',
  ),
  'Guest' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GuestCore' => 
  array (
    'path' => 'classes/Guest.php',
    'type' => 'class',
  ),
  'GuestTrackingController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'GuestTrackingControllerCore' => 
  array (
    'path' => 'controllers/front/GuestTrackingController.php',
    'type' => 'class',
  ),
  'HTMLTemplate' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'HTMLTemplateCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplate.php',
    'type' => 'abstract class',
  ),
  'HTMLTemplateDeliverySlip' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HTMLTemplateDeliverySlipCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplateDeliverySlip.php',
    'type' => 'class',
  ),
  'HTMLTemplateInvoice' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HTMLTemplateInvoiceCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplateInvoice.php',
    'type' => 'class',
  ),
  'HTMLTemplateOrderReturn' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HTMLTemplateOrderReturnCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplateOrderReturn.php',
    'type' => 'class',
  ),
  'HTMLTemplateOrderSlip' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HTMLTemplateOrderSlipCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplateOrderSlip.php',
    'type' => 'class',
  ),
  'HTMLTemplateSupplyOrderForm' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HTMLTemplateSupplyOrderFormCore' => 
  array (
    'path' => 'classes/pdf/HTMLTemplateSupplyOrderForm.php',
    'type' => 'class',
  ),
  'Helper' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperCalendar' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperCalendarCore' => 
  array (
    'path' => 'classes/helper/HelperCalendar.php',
    'type' => 'class',
  ),
  'HelperCore' => 
  array (
    'path' => 'classes/helper/Helper.php',
    'type' => 'class',
  ),
  'HelperForm' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperFormCore' => 
  array (
    'path' => 'classes/helper/HelperForm.php',
    'type' => 'class',
  ),
  'HelperImageUploader' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperImageUploaderCore' => 
  array (
    'path' => 'classes/helper/HelperImageUploader.php',
    'type' => 'class',
  ),
  'HelperKpi' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperKpiCore' => 
  array (
    'path' => 'classes/helper/HelperKpi.php',
    'type' => 'class',
  ),
  'HelperKpiRow' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperKpiRowCore' => 
  array (
    'path' => 'classes/helper/HelperKpiRow.php',
    'type' => 'class',
  ),
  'HelperList' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperListCore' => 
  array (
    'path' => 'classes/helper/HelperList.php',
    'type' => 'class',
  ),
  'HelperOptions' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperOptionsCore' => 
  array (
    'path' => 'classes/helper/HelperOptions.php',
    'type' => 'class',
  ),
  'HelperTreeCategories' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperTreeCategoriesCore' => 
  array (
    'path' => 'classes/helper/HelperTreeCategories.php',
    'type' => 'class',
  ),
  'HelperTreeShops' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperTreeShopsCore' => 
  array (
    'path' => 'classes/helper/HelperTreeShops.php',
    'type' => 'class',
  ),
  'HelperUploader' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperUploaderCore' => 
  array (
    'path' => 'classes/helper/HelperUploader.php',
    'type' => 'class',
  ),
  'HelperView' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HelperViewCore' => 
  array (
    'path' => 'classes/helper/HelperView.php',
    'type' => 'class',
  ),
  'HistoryController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HistoryControllerCore' => 
  array (
    'path' => 'controllers/front/HistoryController.php',
    'type' => 'class',
  ),
  'Hook' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'HookCore' => 
  array (
    'path' => 'classes/Hook.php',
    'type' => 'class',
  ),
  'ITreeToolbar' => 
  array (
    'path' => '',
    'type' => 'interface',
  ),
  'ITreeToolbarButton' => 
  array (
    'path' => '',
    'type' => 'interface',
  ),
  'ITreeToolbarButtonCore' => 
  array (
    'path' => 'classes/tree/ITreeToolbarButton.php',
    'type' => 'interface',
  ),
  'ITreeToolbarCore' => 
  array (
    'path' => 'classes/tree/ITreeToolbar.php',
    'type' => 'interface',
  ),
  'IdentityController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'IdentityControllerCore' => 
  array (
    'path' => 'controllers/front/IdentityController.php',
    'type' => 'class',
  ),
  'Image' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ImageCore' => 
  array (
    'path' => 'classes/Image.php',
    'type' => 'class',
  ),
  'ImageManager' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ImageManagerCore' => 
  array (
    'path' => 'classes/ImageManager.php',
    'type' => 'class',
  ),
  'ImageType' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ImageTypeCore' => 
  array (
    'path' => 'classes/ImageType.php',
    'type' => 'class',
  ),
  'ImportModule' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ImportModuleCore' => 
  array (
    'path' => 'classes/module/ImportModule.php',
    'type' => 'abstract class',
  ),
  'IndexController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'IndexControllerCore' => 
  array (
    'path' => 'controllers/front/IndexController.php',
    'type' => 'class',
  ),
  'Language' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'LanguageCore' => 
  array (
    'path' => 'classes/Language.php',
    'type' => 'class',
  ),
  'Link' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'LinkCore' => 
  array (
    'path' => 'classes/Link.php',
    'type' => 'class',
  ),
  'LocalizationPack' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'LocalizationPackCore' => 
  array (
    'path' => 'classes/LocalizationPack.php',
    'type' => 'class',
  ),
  'Mail' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MailCore' => 
  array (
    'path' => 'classes/Mail.php',
    'type' => 'class',
  ),
  'Manufacturer' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ManufacturerController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ManufacturerControllerCore' => 
  array (
    'path' => 'controllers/front/ManufacturerController.php',
    'type' => 'class',
  ),
  'ManufacturerCore' => 
  array (
    'path' => 'classes/Manufacturer.php',
    'type' => 'class',
  ),
  'Media' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MediaCore' => 
  array (
    'path' => 'classes/Media.php',
    'type' => 'class',
  ),
  'Message' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MessageCore' => 
  array (
    'path' => 'classes/Message.php',
    'type' => 'class',
  ),
  'Meta' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MetaCore' => 
  array (
    'path' => 'classes/Meta.php',
    'type' => 'class',
  ),
  'Module' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleAdminController' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleAdminControllerCore' => 
  array (
    'path' => 'classes/controller/ModuleAdminController.php',
    'type' => 'abstract class',
  ),
  'ModuleCore' => 
  array (
    'path' => 'classes/module/Module.php',
    'type' => 'abstract class',
  ),
  'ModuleFrontController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ModuleFrontControllerCore' => 
  array (
    'path' => 'classes/controller/ModuleFrontController.php',
    'type' => 'class',
  ),
  'ModuleGraph' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleGraphCore' => 
  array (
    'path' => 'classes/module/ModuleGraph.php',
    'type' => 'abstract class',
  ),
  'ModuleGraphEngine' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleGraphEngineCore' => 
  array (
    'path' => 'classes/module/ModuleGraphEngine.php',
    'type' => 'abstract class',
  ),
  'ModuleGrid' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleGridCore' => 
  array (
    'path' => 'classes/module/ModuleGrid.php',
    'type' => 'abstract class',
  ),
  'ModuleGridEngine' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ModuleGridEngineCore' => 
  array (
    'path' => 'classes/module/ModuleGridEngine.php',
    'type' => 'abstract class',
  ),
  'MyAccountController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MyAccountControllerCore' => 
  array (
    'path' => 'controllers/front/MyAccountController.php',
    'type' => 'class',
  ),
  'MySQL' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'MySQLCore' => 
  array (
    'path' => 'classes/db/MySQL.php',
    'type' => 'class',
  ),
  'NewProductsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'NewProductsControllerCore' => 
  array (
    'path' => 'controllers/front/NewProductsController.php',
    'type' => 'class',
  ),
  'Notification' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'NotificationCore' => 
  array (
    'path' => 'classes/Notification.php',
    'type' => 'class',
  ),
  'ObjectModel' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'ObjectModelCore' => 
  array (
    'path' => 'classes/ObjectModel.php',
    'type' => 'abstract class',
  ),
  'Order' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderCarrier' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderCarrierCore' => 
  array (
    'path' => 'classes/order/OrderCarrier.php',
    'type' => 'class',
  ),
  'OrderCartRule' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderCartRuleCore' => 
  array (
    'path' => 'classes/order/OrderCartRule.php',
    'type' => 'class',
  ),
  'OrderConfirmationController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderConfirmationControllerCore' => 
  array (
    'path' => 'controllers/front/OrderConfirmationController.php',
    'type' => 'class',
  ),
  'OrderController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderControllerCore' => 
  array (
    'path' => 'controllers/front/OrderController.php',
    'type' => 'class',
  ),
  'OrderCore' => 
  array (
    'path' => 'classes/order/Order.php',
    'type' => 'class',
  ),
  'OrderDetail' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderDetailController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderDetailControllerCore' => 
  array (
    'path' => 'controllers/front/OrderDetailController.php',
    'type' => 'class',
  ),
  'OrderDetailCore' => 
  array (
    'path' => 'classes/order/OrderDetail.php',
    'type' => 'class',
  ),
  'OrderDiscount' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderDiscountCore' => 
  array (
    'path' => 'classes/order/OrderDiscount.php',
    'type' => 'class',
  ),
  'OrderFollowController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderFollowControllerCore' => 
  array (
    'path' => 'controllers/front/OrderFollowController.php',
    'type' => 'class',
  ),
  'OrderHistory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderHistoryCore' => 
  array (
    'path' => 'classes/order/OrderHistory.php',
    'type' => 'class',
  ),
  'OrderInvoice' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderInvoiceCore' => 
  array (
    'path' => 'classes/order/OrderInvoice.php',
    'type' => 'class',
  ),
  'OrderMessage' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderMessageCore' => 
  array (
    'path' => 'classes/order/OrderMessage.php',
    'type' => 'class',
  ),
  'OrderOpcController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderOpcControllerCore' => 
  array (
    'path' => 'controllers/front/OrderOpcController.php',
    'type' => 'class',
  ),
  'OrderPayment' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderPaymentCore' => 
  array (
    'path' => 'classes/order/OrderPayment.php',
    'type' => 'class',
  ),
  'OrderReturn' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderReturnController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderReturnControllerCore' => 
  array (
    'path' => 'controllers/front/OrderReturnController.php',
    'type' => 'class',
  ),
  'OrderReturnCore' => 
  array (
    'path' => 'classes/order/OrderReturn.php',
    'type' => 'class',
  ),
  'OrderReturnState' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderReturnStateCore' => 
  array (
    'path' => 'classes/order/OrderReturnState.php',
    'type' => 'class',
  ),
  'OrderSlip' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderSlipController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderSlipControllerCore' => 
  array (
    'path' => 'controllers/front/OrderSlipController.php',
    'type' => 'class',
  ),
  'OrderSlipCore' => 
  array (
    'path' => 'classes/order/OrderSlip.php',
    'type' => 'class',
  ),
  'OrderState' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'OrderStateCore' => 
  array (
    'path' => 'classes/order/OrderState.php',
    'type' => 'class',
  ),
  'PDF' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PDFCore' => 
  array (
    'path' => 'classes/pdf/PDF.php',
    'type' => 'class',
  ),
  'PDFGenerator' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PDFGeneratorCore' => 
  array (
    'path' => 'classes/pdf/PDFGenerator.php',
    'type' => 'class',
  ),
  'Pack' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PackCore' => 
  array (
    'path' => 'classes/Pack.php',
    'type' => 'class',
  ),
  'Page' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PageCore' => 
  array (
    'path' => 'classes/Page.php',
    'type' => 'class',
  ),
  'PageNotFoundController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PageNotFoundControllerCore' => 
  array (
    'path' => 'controllers/front/PageNotFoundController.php',
    'type' => 'class',
  ),
  'ParentOrderController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ParentOrderControllerCore' => 
  array (
    'path' => 'controllers/front/ParentOrderController.php',
    'type' => 'class',
  ),
  'PasswordController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PasswordControllerCore' => 
  array (
    'path' => 'controllers/front/PasswordController.php',
    'type' => 'class',
  ),
  'PaymentCC' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PaymentCCCore' => 
  array (
    'path' => 'classes/PaymentCC.php',
    'type' => 'class',
  ),
  'PaymentModule' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'PaymentModuleCore' => 
  array (
    'path' => 'classes/PaymentModule.php',
    'type' => 'abstract class',
  ),
  'PdfInvoiceController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PdfInvoiceControllerCore' => 
  array (
    'path' => 'controllers/front/PdfInvoiceController.php',
    'type' => 'class',
  ),
  'PdfOrderReturnController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PdfOrderReturnControllerCore' => 
  array (
    'path' => 'controllers/front/PdfOrderReturnController.php',
    'type' => 'class',
  ),
  'PdfOrderSlipController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PdfOrderSlipControllerCore' => 
  array (
    'path' => 'controllers/front/PdfOrderSlipController.php',
    'type' => 'class',
  ),
  'PrestaShopAutoload' => 
  array (
    'path' => 'classes/PrestaShopAutoload.php',
    'type' => 'class',
  ),
  'PrestaShopBackup' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopBackupCore' => 
  array (
    'path' => 'classes/PrestaShopBackup.php',
    'type' => 'class',
  ),
  'PrestaShopCollection' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopCollectionCore' => 
  array (
    'path' => 'classes/PrestaShopCollection.php',
    'type' => 'class',
  ),
  'PrestaShopDatabaseException' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopDatabaseExceptionCore' => 
  array (
    'path' => 'classes/exception/PrestaShopDatabaseException.php',
    'type' => 'class',
  ),
  'PrestaShopException' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopExceptionCore' => 
  array (
    'path' => 'classes/exception/PrestaShopException.php',
    'type' => 'class',
  ),
  'PrestaShopLogger' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopLoggerCore' => 
  array (
    'path' => 'classes/PrestaShopLogger.php',
    'type' => 'class',
  ),
  'PrestaShopModuleException' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopModuleExceptionCore' => 
  array (
    'path' => 'classes/exception/PrestaShopModuleException.php',
    'type' => 'class',
  ),
  'PrestaShopPaymentException' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PrestaShopPaymentExceptionCore' => 
  array (
    'path' => 'classes/exception/PrestaShopPaymentException.php',
    'type' => 'class',
  ),
  'PricesDropController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'PricesDropControllerCore' => 
  array (
    'path' => 'controllers/front/PricesDropController.php',
    'type' => 'class',
  ),
  'Product' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProductController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProductControllerCore' => 
  array (
    'path' => 'controllers/front/ProductController.php',
    'type' => 'class',
  ),
  'ProductCore' => 
  array (
    'path' => 'classes/Product.php',
    'type' => 'class',
  ),
  'ProductDownload' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProductDownloadCore' => 
  array (
    'path' => 'classes/ProductDownload.php',
    'type' => 'class',
  ),
  'ProductSale' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProductSaleCore' => 
  array (
    'path' => 'classes/ProductSale.php',
    'type' => 'class',
  ),
  'ProductSupplier' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProductSupplierCore' => 
  array (
    'path' => 'classes/ProductSupplier.php',
    'type' => 'class',
  ),
  'Profile' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ProfileCore' => 
  array (
    'path' => 'classes/Profile.php',
    'type' => 'class',
  ),
  'QuickAccess' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'QuickAccessCore' => 
  array (
    'path' => 'classes/QuickAccess.php',
    'type' => 'class',
  ),
  'RangePrice' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'RangePriceCore' => 
  array (
    'path' => 'classes/range/RangePrice.php',
    'type' => 'class',
  ),
  'RangeWeight' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'RangeWeightCore' => 
  array (
    'path' => 'classes/range/RangeWeight.php',
    'type' => 'class',
  ),
  'Referrer' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ReferrerCore' => 
  array (
    'path' => 'classes/Referrer.php',
    'type' => 'class',
  ),
  'RequestSql' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'RequestSqlCore' => 
  array (
    'path' => 'classes/RequestSql.php',
    'type' => 'class',
  ),
  'Rijndael' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'RijndaelCore' => 
  array (
    'path' => 'classes/Rijndael.php',
    'type' => 'class',
  ),
  'Risk' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'RiskCore' => 
  array (
    'path' => 'classes/Risk.php',
    'type' => 'class',
  ),
  'Scene' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SceneCore' => 
  array (
    'path' => 'classes/Scene.php',
    'type' => 'class',
  ),
  'Search' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SearchController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SearchControllerCore' => 
  array (
    'path' => 'controllers/front/SearchController.php',
    'type' => 'class',
  ),
  'SearchCore' => 
  array (
    'path' => 'classes/Search.php',
    'type' => 'class',
  ),
  'SearchEngine' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SearchEngineCore' => 
  array (
    'path' => 'classes/SearchEngine.php',
    'type' => 'class',
  ),
  'Shop' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ShopCore' => 
  array (
    'path' => 'classes/shop/Shop.php',
    'type' => 'class',
  ),
  'ShopGroup' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ShopGroupCore' => 
  array (
    'path' => 'classes/shop/ShopGroup.php',
    'type' => 'class',
  ),
  'ShopUrl' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ShopUrlCore' => 
  array (
    'path' => 'classes/shop/ShopUrl.php',
    'type' => 'class',
  ),
  'SitemapController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SitemapControllerCore' => 
  array (
    'path' => 'controllers/front/SitemapController.php',
    'type' => 'class',
  ),
  'SpecificPrice' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SpecificPriceCore' => 
  array (
    'path' => 'classes/SpecificPrice.php',
    'type' => 'class',
  ),
  'SpecificPriceRule' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SpecificPriceRuleCore' => 
  array (
    'path' => 'classes/SpecificPriceRule.php',
    'type' => 'class',
  ),
  'State' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StateCore' => 
  array (
    'path' => 'classes/State.php',
    'type' => 'class',
  ),
  'StatisticsController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StatisticsControllerCore' => 
  array (
    'path' => 'controllers/front/StatisticsController.php',
    'type' => 'class',
  ),
  'Stock' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockAvailable' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockAvailableCore' => 
  array (
    'path' => 'classes/stock/StockAvailable.php',
    'type' => 'class',
  ),
  'StockCore' => 
  array (
    'path' => 'classes/stock/Stock.php',
    'type' => 'class',
  ),
  'StockManager' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockManagerCore' => 
  array (
    'path' => 'classes/stock/StockManager.php',
    'type' => 'class',
  ),
  'StockManagerFactory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockManagerFactoryCore' => 
  array (
    'path' => 'classes/stock/StockManagerFactory.php',
    'type' => 'class',
  ),
  'StockManagerInterface' => 
  array (
    'path' => 'classes/stock/StockManagerInterface.php',
    'type' => 'interface',
  ),
  'StockManagerModule' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'StockManagerModuleCore' => 
  array (
    'path' => 'classes/stock/StockManagerModule.php',
    'type' => 'abstract class',
  ),
  'StockMvt' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockMvtCore' => 
  array (
    'path' => 'classes/stock/StockMvt.php',
    'type' => 'class',
  ),
  'StockMvtReason' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockMvtReasonCore' => 
  array (
    'path' => 'classes/stock/StockMvtReason.php',
    'type' => 'class',
  ),
  'StockMvtWS' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StockMvtWSCore' => 
  array (
    'path' => 'classes/stock/StockMvtWS.php',
    'type' => 'class',
  ),
  'Store' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StoreCore' => 
  array (
    'path' => 'classes/Store.php',
    'type' => 'class',
  ),
  'StoresController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'StoresControllerCore' => 
  array (
    'path' => 'controllers/front/StoresController.php',
    'type' => 'class',
  ),
  'Supplier' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplierController' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplierControllerCore' => 
  array (
    'path' => 'controllers/front/SupplierController.php',
    'type' => 'class',
  ),
  'SupplierCore' => 
  array (
    'path' => 'classes/Supplier.php',
    'type' => 'class',
  ),
  'SupplyOrder' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplyOrderCore' => 
  array (
    'path' => 'classes/stock/SupplyOrder.php',
    'type' => 'class',
  ),
  'SupplyOrderDetail' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplyOrderDetailCore' => 
  array (
    'path' => 'classes/stock/SupplyOrderDetail.php',
    'type' => 'class',
  ),
  'SupplyOrderHistory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplyOrderHistoryCore' => 
  array (
    'path' => 'classes/stock/SupplyOrderHistory.php',
    'type' => 'class',
  ),
  'SupplyOrderReceiptHistory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplyOrderReceiptHistoryCore' => 
  array (
    'path' => 'classes/stock/SupplyOrderReceiptHistory.php',
    'type' => 'class',
  ),
  'SupplyOrderState' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'SupplyOrderStateCore' => 
  array (
    'path' => 'classes/stock/SupplyOrderState.php',
    'type' => 'class',
  ),
  'Tab' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TabCore' => 
  array (
    'path' => 'classes/Tab.php',
    'type' => 'class',
  ),
  'Tag' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TagCore' => 
  array (
    'path' => 'classes/Tag.php',
    'type' => 'class',
  ),
  'Tax' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxCalculator' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxCalculatorCore' => 
  array (
    'path' => 'classes/tax/TaxCalculator.php',
    'type' => 'class',
  ),
  'TaxCore' => 
  array (
    'path' => 'classes/tax/Tax.php',
    'type' => 'class',
  ),
  'TaxManagerFactory' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxManagerFactoryCore' => 
  array (
    'path' => 'classes/tax/TaxManagerFactory.php',
    'type' => 'class',
  ),
  'TaxManagerInterface' => 
  array (
    'path' => 'classes/tax/TaxManagerInterface.php',
    'type' => 'interface',
  ),
  'TaxManagerModule' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'TaxManagerModuleCore' => 
  array (
    'path' => 'classes/tax/TaxManagerModule.php',
    'type' => 'abstract class',
  ),
  'TaxRule' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxRuleCore' => 
  array (
    'path' => 'classes/tax/TaxRule.php',
    'type' => 'class',
  ),
  'TaxRulesGroup' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxRulesGroupCore' => 
  array (
    'path' => 'classes/tax/TaxRulesGroup.php',
    'type' => 'class',
  ),
  'TaxRulesTaxManager' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TaxRulesTaxManagerCore' => 
  array (
    'path' => 'classes/tax/TaxRulesTaxManager.php',
    'type' => 'class',
  ),
  'Theme' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ThemeCore' => 
  array (
    'path' => 'classes/Theme.php',
    'type' => 'class',
  ),
  'Tools' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ToolsCore' => 
  array (
    'path' => 'classes/Tools.php',
    'type' => 'class',
  ),
  'Translate' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TranslateCore' => 
  array (
    'path' => 'classes/Translate.php',
    'type' => 'class',
  ),
  'TranslatedConfiguration' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TranslatedConfigurationCore' => 
  array (
    'path' => 'classes/TranslatedConfiguration.php',
    'type' => 'class',
  ),
  'Tree' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TreeCore' => 
  array (
    'path' => 'classes/tree/Tree.php',
    'type' => 'class',
  ),
  'TreeToolbar' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TreeToolbarButton' => 
  array (
    'path' => '',
    'type' => 'abstract class',
  ),
  'TreeToolbarButtonCore' => 
  array (
    'path' => 'classes/tree/TreeToolbarButton.php',
    'type' => 'abstract class',
  ),
  'TreeToolbarCore' => 
  array (
    'path' => 'classes/tree/TreeToolbar.php',
    'type' => 'class',
  ),
  'TreeToolbarLink' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TreeToolbarLinkCore' => 
  array (
    'path' => 'classes/tree/TreeToolbarLink.php',
    'type' => 'class',
  ),
  'TreeToolbarSearch' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TreeToolbarSearchCategories' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'TreeToolbarSearchCategoriesCore' => 
  array (
    'path' => 'classes/tree/TreeToolbarSearchCategories.php',
    'type' => 'class',
  ),
  'TreeToolbarSearchCore' => 
  array (
    'path' => 'classes/tree/TreeToolbarSearch.php',
    'type' => 'class',
  ),
  'Upgrader' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'UpgraderCore' => 
  array (
    'path' => 'classes/Upgrader.php',
    'type' => 'class',
  ),
  'Uploader' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'UploaderCore' => 
  array (
    'path' => 'classes/Uploader.php',
    'type' => 'class',
  ),
  'Validate' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ValidateCore' => 
  array (
    'path' => 'classes/Validate.php',
    'type' => 'class',
  ),
  'Warehouse' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WarehouseCore' => 
  array (
    'path' => 'classes/stock/Warehouse.php',
    'type' => 'class',
  ),
  'WarehouseProductLocation' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WarehouseProductLocationCore' => 
  array (
    'path' => 'classes/stock/WarehouseProductLocation.php',
    'type' => 'class',
  ),
  'WebserviceException' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceExceptionCore' => 
  array (
    'path' => 'classes/webservice/WebserviceException.php',
    'type' => 'class',
  ),
  'WebserviceKey' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceKeyCore' => 
  array (
    'path' => 'classes/webservice/WebserviceKey.php',
    'type' => 'class',
  ),
  'WebserviceOutputBuilder' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceOutputBuilderCore' => 
  array (
    'path' => 'classes/webservice/WebserviceOutputBuilder.php',
    'type' => 'class',
  ),
  'WebserviceOutputInterface' => 
  array (
    'path' => 'classes/webservice/WebserviceOutputInterface.php',
    'type' => 'interface',
  ),
  'WebserviceOutputXML' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceOutputXMLCore' => 
  array (
    'path' => 'classes/webservice/WebserviceOutputXML.php',
    'type' => 'class',
  ),
  'WebserviceRequest' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceRequestCore' => 
  array (
    'path' => 'classes/webservice/WebserviceRequest.php',
    'type' => 'class',
  ),
  'WebserviceSpecificManagementImages' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceSpecificManagementImagesCore' => 
  array (
    'path' => 'classes/webservice/WebserviceSpecificManagementImages.php',
    'type' => 'class',
  ),
  'WebserviceSpecificManagementInterface' => 
  array (
    'path' => 'classes/webservice/WebserviceSpecificManagementInterface.php',
    'type' => 'interface',
  ),
  'WebserviceSpecificManagementSearch' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'WebserviceSpecificManagementSearchCore' => 
  array (
    'path' => 'classes/webservice/WebserviceSpecificManagementSearch.php',
    'type' => 'class',
  ),
  'Zone' => 
  array (
    'path' => '',
    'type' => 'class',
  ),
  'ZoneCore' => 
  array (
    'path' => 'classes/Zone.php',
    'type' => 'class',
  ),
); ?>